
## GPT 응답생성
## 시스템 프롬프트, 메모리 기반 응답, 쿼리 타입 감지 포함


## 챗봇 응답에 관한 응답함수들을 이 파일로 다 뺴놓을거임
## 그래야 프롬프트 수정에 있어서 용이하기땜시
## 시스템 프롬프트, 메모리 기반 응답, 쿼리 타입 감지 포함

# ---------------------------------------------------------------------
# 6/30 업데이트 사항
# BufferMemory 관련 코드 수정
# get_cahtbot_response()를 memory기반으로 재작성
# chat.py도 변경
# memory_store.py 새로 생성 : LangChain 초기화 및 memory 저장용 딕셔너리
# get_chatbot_response() 함수가 history 대신 memory를 받아서 응답 생성
# LangChain의 ConversationChain 사용
# ------------------------------------------------------------------------


# app/openai_helper.py
from openai import OpenAI
import os
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains import LLMChain
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder


# --------------------------------------------------------------------------------

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
llm = ChatOpenAI(model="gpt-4o")

# -------------------------------------------------------------------------------


# 🎯 LangChain 기반 응답 memory (유저별로 분리)
user_memory_store = {}


def get_user_memory(pk: str) -> ConversationBufferMemory:
    if pk not in user_memory_store:
        user_memory_store[pk] = ConversationBufferMemory(return_messages=True)
    return user_memory_store[pk]



# --------------------------------------------------------------------------------
# (유저 인풋+시스템프롬프트+버퍼메모리)를 기반으로 응답생성하는 함수
async def get_chatbot_response(
    user_input: str,
    system_prompt: str,
    memory: ConversationBufferMemory) -> str:


    # LangChain message 리스트 구성
    # 1. 대화 이력 정리
    chat_history = memory.chat_memory.messages
    messages = [{"role": "system", "content": system_prompt}]

    for msg in chat_history:
        if msg.type == "human":
            messages.append({"role": "user", "content": msg.content})
        elif msg.type == "ai":
            messages.append({"role": "assistant", "content": msg.content})
    
    # 2. 최신 유저 입력 추가
    messages.append({"role": "user", "content": user_input})
    
    # 3. 지피티 응답 생성
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            temperature=0.7
        )
        return response.choices[0].message.content.strip()

    except Exception as e:
        print(f"[GPT 응답 실패] {e}")
        return "⚠️ 답변 생성 중 오류가 발생했어요. 잠시 후 다시 시도해줘!"

# ---------------------------------------------------------------------------------

# 쿼리 타입 감지 (개인기록 / 외부정보 / 일반대화)
def detect_query_type(message: str) -> str:
    prompt = f"""
    다음 유저의 발화를 읽고, 어떤 응답 방식이 적절한지 하나만 골라줘.
    - 개인기록검색
    - 외부정보검색
    - 일반대화

    유저 발화: "{message}"
    적절한 방식:"""

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.0,
    )
    return response.choices[0].message.content.strip()


# ✅ FAISS 기반 개인기록 검색 + GPT 응답 생성 함수
from .faiss_helper import search_from_faiss

async def get_rag_response(user_input: str, system_prompt: str, memory: ConversationBufferMemory, pk: str) -> str:
    # 1. FAISS 벡터 DB에서 유사한 과거 대화 검색
    retrieved_chunks = search_from_faiss(pk, user_input, k=3)

    if not retrieved_chunks:
        return "🧠 과거 대화 중 관련된 내용을 찾지 못했어. 다시 한번 말해줄 수 있을까?"

    # 2. 검색 결과를 하나의 문자열로 정리
    context_summary = "\n".join([f"- {chunk}" for chunk in retrieved_chunks])

    # 3. GPT 응답 생성
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"""
다음은 유저의 과거 대화 기록 일부야. 참고해서 지금 질문에 자연스럽게 이어서 답변해줘.

[과거 기록]
{context_summary}

[현재 질문]
{user_input}
"""}
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            temperature=0.7
        )
        reply = response.choices[0].message.content.strip()

        # 메모리 업데이트
        memory.chat_memory.add_user_message(user_input)
        memory.chat_memory.add_ai_message(reply)

        return reply

    except Exception as e:
        print(f"[RAG 응답 실패] {e}")
        return "⚠️ 답변 생성 중 오류가 발생했어요. 잠시 후 다시 시도해줘!"
    
# ✅ 벡터 검색 필요 여부 판단 (vector vs memory)
def should_use_vector_search(user_input: str) -> bool:
    try:
        prompt = f"""
다음 사용자의 질문이 과거 대화 기록을 기반으로 검색해야 할 내용인지 판단해줘.

질문: "{user_input}"

답변 형식은 반드시 다음 중 하나로 해줘:
- vector → 과거 대화 검색 필요
- memory → 현재 대화 흐름에 응답

정답:
"""

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
        )
        answer = response.choices[0].message.content.strip().lower()
        return "vector" in answer

    except Exception as e:
        print(f"[쿼리 분류 실패] {e}")
        return False

